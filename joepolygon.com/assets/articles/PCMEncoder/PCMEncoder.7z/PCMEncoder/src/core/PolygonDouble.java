package core;

import java.awt.Polygon;

/**
 * 
 * @author Joe Pelz
 * @version 1.0
 */
public class PolygonDouble {
    public double[] xpoints;
    public double[] ypoints;
    public int npoints;
    
    public PolygonDouble(double[] xpoints, double[] ypoints, int npoints) {
        this.xpoints = xpoints;
        this.ypoints = ypoints;
        this.npoints = npoints;
    }
    
    public Polygon toPolygon(double multiplyX, double multiplyY) {
        int[] xp = new int[npoints];
        int[] yp = new int[npoints];
        for (int i = 0; i < npoints; i++) {
            xp[i] = (int) (xpoints[i] * multiplyX);
            yp[i] = (int) (ypoints[i] * multiplyY);
        }
        Polygon result = new Polygon(xp, yp, npoints);
        return result;
    }
}
