/**
 * 
 */
package core;

/**
 * 
 * @author Joe Pelz
 * @version 1.0
 */
public interface Wave {
    double sample(double time);
    double getAmplitude();
}
