/**
 * 
 */
package core;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * 
 * @author Joe Pelz
 * @version 1.0
 */
public class Main {

    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("PCM Encoder");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (ClassNotFoundException | InstantiationException
                | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        
        JTabbedPane tabbedPane = new JTabbedPane();
        
        JPanel signalPanel = new SignalPanel();
        
        tabbedPane.addTab("Pulse Code Modulation", null, signalPanel, "Sine wave compositor");
        frame.add(tabbedPane);
        
        frame.pack();
        frame.setVisible(true);
    }

}
