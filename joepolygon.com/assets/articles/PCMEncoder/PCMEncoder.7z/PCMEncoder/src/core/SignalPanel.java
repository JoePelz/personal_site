package core;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.NumberFormat;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JToolBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * 
 * @author Joe Pelz
 * @version 1.0
 */
public class SignalPanel extends JPanel {
    private int sampleRate = 4375;
    private int levelBits = 3;
    
    private WavePanel FD = new WavePanel();
    private WavePanel base = new WavePanel();
    private WavePanel sampled = new WavePanel();
    private WavePanel quantized = new WavePanel();
    private WavePanel reconstructed = new WavePanel();
    private JSlider sampleSlider = new JSlider();
    
    private CompositeWave wave;
    private SimpleWave selectedWave = null;
    
    public SignalPanel() {
        setPreferredSize(new Dimension(800, 900));
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

        wave = new CompositeWave();
        SimpleWave testWave = new SimpleWave(440, 1, 0);
        wave.add(testWave);
        testWave = new SimpleWave(586.6666, 0.6666, 0);
        wave.add(testWave);
        testWave = new SimpleWave(696.6666, 0.4444, 0);
        wave.add(testWave);
        testWave = new SimpleWave(880, 0.1975, 0);
        wave.add(testWave);
        
        
        addModuleFD();

        addModuleBase();

        addModuleSampled();
        
        addModuleQuantized();
        
        addModuleReconstructed();
        
        setSamplingRate(sampleRate);
        setLevelBits(levelBits);
    }

    private void addModuleBase() {
        JPanel baseWave = new JPanel();
        baseWave.setLayout(new BoxLayout(baseWave, BoxLayout.LINE_AXIS));
        baseWave.setAlignmentX(LEFT_ALIGNMENT);
        baseWave.add(Box.createRigidArea(new Dimension(10,0)));
        final JButton sndPlay = new JButton("Play Sound Sample");
        baseWave.add(sndPlay);
        add(baseWave);
        
        
        base.setWave(wave);
        base.drawBaseWave = true;
        base.setAlignmentX(LEFT_ALIGNMENT);
        base.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                base.drawSimpleWaves = !base.drawSimpleWaves;
                base.drawBaseWave = !base.drawBaseWave;
                base.repaint();
            }
        });
        add(base);
        
        sndPlay.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WavePlayer wp = new WavePlayer();
                wp.setWave(wave);
                wp.play();
            }
        });
    }
    
    private void addModuleFD() {
        JPanel fdPlotting = new JPanel();
        fdPlotting.setLayout(new BoxLayout(fdPlotting, BoxLayout.LINE_AXIS));
        fdPlotting.add(Box.createRigidArea(new Dimension(10,0)));
        fdPlotting.add(new JLabel("Frequency Domain plot"));
        fdPlotting.add(new JToolBar.Separator());
        fdPlotting.add(new JLabel("Frequency:"));
        final JFormattedTextField fFreq = new JFormattedTextField(NumberFormat.getNumberInstance());
        fFreq.setMaximumSize(new Dimension(200, 50));
        fdPlotting.add(fFreq);
        fdPlotting.add(new JLabel("Amplitude:"));
        final JFormattedTextField fAmp = new JFormattedTextField(NumberFormat.getNumberInstance());
        fAmp.setMaximumSize(new Dimension(200, 50));
        fdPlotting.add(fAmp);
        fdPlotting.add(new JLabel("Phase (in cycles):"));
        final JFormattedTextField fPhase = new JFormattedTextField(NumberFormat.getNumberInstance());
        fPhase.setMaximumSize(new Dimension(200, 50));
        fdPlotting.add(fPhase);
        fdPlotting.add(Box.createRigidArea(new Dimension(10,0)));
        fdPlotting.setAlignmentX(LEFT_ALIGNMENT);
        add(fdPlotting);
        final JButton btnDel = new JButton("Remove");
        btnDel.setMaximumSize(new Dimension(100, 50));
        fdPlotting.add(btnDel);
        
        FD = new WavePanel();
        FD.setWave(wave);
        FD.drawWaveFD = true;
        FD.setAlignmentX(LEFT_ALIGNMENT);
        add(FD);
        
        fFreq.setValue(new Double(500.0));
        fAmp.setValue(new Double(1.0));
        fPhase.setValue(new Double(0.0));
        
        FD.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                selectedWave = FD.getClickFD((double)e.getX() / FD.getSize().width);
                base.setSelectedWave(selectedWave);
                fFreq.setValue(new Double(selectedWave.getFrequency()));
                fAmp.setValue(new Double(selectedWave.getAmplitude()));
                fPhase.setValue(new Double(selectedWave.getPhase()));
                repaintAll();
            }
        });

        fPhase.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                Number val = (Number)fPhase.getValue();
                if (selectedWave != null) {
                    selectedWave.setPhase(val.doubleValue());
                    repaintAll();
                }
            }
        });
        
        fPhase.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    Number val = (Number)fPhase.getValue();
                    Double newVal = val.doubleValue() + 0.01;
                    fPhase.setValue(newVal);
                    if (selectedWave != null) {
                        selectedWave.setPhase(newVal);
                        repaintAll();
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    Number val = (Number)fPhase.getValue();
                    Double newVal = val.doubleValue() - 0.01;
                    fPhase.setValue(newVal);
                    if (selectedWave != null) {
                        selectedWave.setPhase(newVal);
                        repaintAll();
                    }
                }
            }
        });
        
        fAmp.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                Number val = (Number)fAmp.getValue();
                if (selectedWave != null) {
                    selectedWave.setAmplitude(val.doubleValue());
                    repaintAll();
                }
            }
        });
        
        fAmp.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    Number val = (Number)fAmp.getValue();
                    Double newVal = val.doubleValue() + 0.01;
                    fAmp.setValue(newVal);
                    if (selectedWave != null) {
                        selectedWave.setAmplitude(newVal);
                        repaintAll();
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    Number val = (Number)fAmp.getValue();
                    Double newVal = val.doubleValue() - 0.01;
                    fAmp.setValue(newVal);
                    if (selectedWave != null) {
                        selectedWave.setAmplitude(newVal);
                        repaintAll();
                    }
                }
            }
        });
        
        fFreq.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                Number val = (Number)fFreq.getValue();
                if (selectedWave != null) {
                    selectedWave.setFrequency(val.doubleValue());
                    repaintAll();
                }
            }
        });
        
        fFreq.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    Number val = (Number)fFreq.getValue();
                    Double newVal = val.doubleValue() * 1.01;
                    fFreq.setValue(newVal);
                    if (selectedWave != null) {
                        selectedWave.setFrequency(newVal);
                        repaintAll();
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    Number val = (Number)fFreq.getValue();
                    Double newVal = val.doubleValue() * 0.99;
                    fFreq.setValue(newVal);
                    if (selectedWave != null) {
                        selectedWave.setFrequency(newVal);
                        repaintAll();
                    }
                }
            }
        });
        
        btnDel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                wave.remove(selectedWave);
                repaintAll();
            }
        });
    }
    
    private void addModuleSampled() {
        JPanel sampling = new JPanel();
        sampling.setLayout(new BoxLayout(sampling, BoxLayout.LINE_AXIS));
        sampling.add(Box.createRigidArea(new Dimension(10,0)));
        sampling.add(new JLabel("Samples: "));
        updateSlider();
        sampleSlider.setValue(4375);
        sampling.add(sampleSlider);
        sampling.add(Box.createRigidArea(new Dimension(10,0)));
        final JLabel lblSampleRate = new JLabel(sampleRate + " samples / second");
        sampling.add(lblSampleRate);
        sampling.add(Box.createRigidArea(new Dimension(10,0)));
        sampling.setAlignmentX(LEFT_ALIGNMENT);
        add(sampling);
        
        sampled.setWave(wave);
        sampled.drawSampledWave = true;
        sampled.drawBaseWave = true;
        sampled.setAlignmentX(LEFT_ALIGNMENT);
        add(sampled);

        sampleSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                setSamplingRate(sampleSlider.getValue());
                lblSampleRate.setText(sampleRate + " samples / second");
            }
        });
    }

    /**
     * 
     */
    private void updateSlider() {
        if (wave == null || wave.getFMax() == 0) {
            return;
        }
        int oldVal = sampleSlider.getValue();
        sampleSlider.setMinimum((int)wave.getFundamental());
        sampleSlider.setMaximum((int)wave.getFMax() * 30);
        if (oldVal < sampleSlider.getMinimum()) {
            sampleSlider.setValue(sampleSlider.getMinimum());
        } else if (oldVal > sampleSlider.getMaximum()) {
            sampleSlider.setValue(sampleSlider.getMaximum());
        }
    }

    private void addModuleQuantized() {
        JPanel quantizing = new JPanel();
        quantizing.setLayout(new BoxLayout(quantizing, BoxLayout.LINE_AXIS));
        
        final JSlider slider = new JSlider(1, 16, 3);
        quantizing.add(Box.createRigidArea(new Dimension(10,0)));
        quantizing.add(new JLabel("Bits per sample: "));
        quantizing.add(slider);
        quantizing.add(Box.createRigidArea(new Dimension(10,0)));
        final JLabel lblQuantized = new JLabel(levelBits + " bits (" + (1 << levelBits) + " levels)");
        lblQuantized.setAlignmentX(LEFT_ALIGNMENT);
        quantizing.add(lblQuantized);
        quantizing.add(Box.createRigidArea(new Dimension(10,0)));
        quantizing.setAlignmentX(LEFT_ALIGNMENT);
        add(quantizing);
        
        quantized.setWave(wave);
        quantized.drawQuantizedWave = true;
        quantized.drawSampledWave = true;
        quantized.setAlignmentX(LEFT_ALIGNMENT);
        add(quantized);

        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                setLevelBits(slider.getValue());
                lblQuantized.setText(levelBits + " bits (" + (int)(Math.pow(2, levelBits)) + " levels)");
            }
        });
    }

    private void addModuleReconstructed() {
        JLabel lblReconstructed = new JLabel("  ");
        lblReconstructed.setAlignmentX(LEFT_ALIGNMENT);
        add(lblReconstructed);
        reconstructed.setWave(wave);
        reconstructed.drawReconstructedWave = true;
        reconstructed.drawQuantizedWave = true;
        reconstructed.setAlignmentX(LEFT_ALIGNMENT);
        add(reconstructed);
    }

    private void setSamplingRate(int rate) {
        sampleRate = rate;
        FD.setSampleRate(rate);
        base.setSampleRate(rate);
        sampled.setSampleRate(rate);
        quantized.setSampleRate(rate);
        reconstructed.setSampleRate(rate);
    }

    private void setLevelBits(int bits) {
        levelBits = bits;
        FD.setLevelBits(bits);
        base.setLevelBits(bits);
        sampled.setLevelBits(bits);
        quantized.setLevelBits(bits);
        reconstructed.setLevelBits(bits);
    }

    private void repaintAll() {
        updateSlider();
        FD.repaint();
        base.repaint();
        sampled.repaint();
        quantized.repaint();
        reconstructed.repaint();
    }
}
