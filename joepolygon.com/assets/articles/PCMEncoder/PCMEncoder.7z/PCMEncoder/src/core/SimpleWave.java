/**
 * 
 */
package core;


/**
 * 
 * @author Joe Pelz
 * @version 1.0
 */
public class SimpleWave implements Wave {
    private double frequency;
    private double amplitude;
    private double phase;
    
    public SimpleWave() {}
    public SimpleWave(double frequency) {
        this.frequency = frequency;
        this.amplitude = 0.5;
    }
    public SimpleWave(double frequency, double amplitude) {
        this.frequency = frequency;
        this.amplitude = amplitude;
    }
    public SimpleWave(double frequency, double amplitude, double phase) {
        this.frequency = frequency;
        this.amplitude = amplitude;
        this.phase = phase;
    }

    public double getFrequency() {
        return frequency;
    }
    public void setFrequency(double frequency) {
        this.frequency = frequency;
    }
    public double getPeriod() {
        return 1.0 / frequency;
    }
    public void setPeriod(double period) {
        this.frequency = 1.0 / period;
    }
    public double getAmplitude() {
        return amplitude;
    }
    public void setAmplitude(double amplitude) {
        this.amplitude = amplitude;
    }
    public double getPhase() {
        return phase;
    }
    public void setPhase(double phase) {
        this.phase = phase;
    }

    @Override
    public double sample(double time) {
        return amplitude * Math.sin(2 * Math.PI * (frequency * time + phase));
    }

    public double sampleNormalized(double time) {
        return sample(time) / getAmplitude();
    }
}
