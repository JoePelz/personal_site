package core;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;

import javax.swing.JPanel;

/**
 * 
 * @author Joe Pelz
 * @version 1.0
 */
public class WavePanel extends JPanel {
    /** The portion of the panel vertical size that is used. */
    final static private double V_USED = 0.9;
    /** The portion of the panel horizontal size that is used. 
     * (by the frequency domain plot) */
    final static private double H_USED = 0.7;
    private CompositeWave wave = new CompositeWave();
    private SimpleWave selectedWave;
    private double range;
    private double sampleRate;
    private int levelBits;

    public boolean drawWaveFD;
    public boolean drawBaseWave;
    public boolean drawSimpleWaves;
    public boolean drawSampledWave;
    public boolean drawQuantizedWave;
    public boolean drawReconstructedWave;

    public WavePanel() {
        setFont(getFont().deriveFont(20f));
    }
    
    public void setWave(CompositeWave wave) {
        this.wave = wave;
        range = 3.0 / wave.getFundamental();
    }
    
    private PolygonDouble sampleWave(CompositeWave wave, double sampleRate, double timeStart, double timeEnd) {
        return sampleWave(wave, sampleRate, timeStart, timeEnd, true);
    }
    
    private PolygonDouble sampleWave(CompositeWave wave, double sampleRate, double timeStart, double timeEnd, boolean normalized) {
        int samples = (int) ((timeEnd - timeStart) * sampleRate) + 1;
        double[] xpoints = new double[samples+1];
        double[] ypoints = new double[samples+1];
        double time = 0;
        if (normalized) {
            for(int i=0; i <= samples; i++) {
                time = 1.0 / sampleRate * i + timeStart;
                xpoints[i] = (time + timeStart) / range;
                ypoints[i] = -wave.sampleNormalized(time);
            }
        } else {
            for(int i=0; i <= samples; i++) {
                time = 1.0 / sampleRate * i + timeStart;
                xpoints[i] = (time + timeStart) / range;
                ypoints[i] = -wave.sample(time);
            }
        }
        return new PolygonDouble(xpoints, ypoints, samples+1);
    }
    
    private PolygonDouble sampleWaveQuantized(CompositeWave wave, double sampleRate, double timeStart, double timeEnd, int levelBits) {
        PolygonDouble sample = sampleWave(wave, sampleRate, timeStart, timeEnd);
        double[] xpoints = new double[sample.npoints * 2];
        double[] ypoints = new double[sample.npoints * 2];
        int index = 0;
        double levels = 1 << levelBits;
        double time, newLevel;
        
        for(int i=0; i < sample.npoints; i++) {
            time = 1.0 / sampleRate * i + timeStart;

            newLevel = quantize(-wave.sampleNormalized(time), 2, levels);
            
            ypoints[index] = (i > 0) ? ypoints[index - 1] : newLevel;
            xpoints[index++] = (time + timeStart) / range;
            
            ypoints[index] = newLevel;
            xpoints[index++] = (time + timeStart) / range;
        }
        return new PolygonDouble(xpoints, ypoints, sample.npoints * 2);
    }
    private double quantize(double value, double height, double levels) {
        //resolve rounding error generating an extra level.
        if (value >= height / 2) {
            value = height / 2 - 0.00001;
        }
        
        double lh = height / levels;
        double result = value + lh / 2;
        result = lh * Math.round(result / lh);
        result -= lh / 2;
        return result;
    }

    @Override
    public void paintComponent(Graphics g) {
        range = 3.0 / wave.getFundamental();
        drawBG(g);
        Rectangle r = g.getClipBounds();

        ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, // Anti-alias!
                RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.setColor(new Color(0xFF888888));
        if (drawWaveFD) {
            g.drawString("Frequency Domain Plot. Bandwidth: " + (int)(wave.getBandwidth()) + "Hz", 10, r.height - 10);
            drawFD(g);
            
        } else if (drawSimpleWaves) {
            g.drawString("Time Range: " + getTimeString(), r.width - 200, r.height - 10);
            g.drawString("Simple Waves", 10, r.height - 10);
            g.setColor(Color.BLACK);
            drawSimpleWaves(g);
            
        } else if (drawReconstructedWave) {
            g.drawString("Reconstructed Signal. Bitrate: " + getBitRate(), 10, r.height - 10);
            g.setColor(Color.LIGHT_GRAY);
            if (drawQuantizedWave)
                drawQuantizedWave(g);
            if (drawSampledWave)
                drawSampledWave(g);
            if (drawBaseWave)
                drawWave(g);
            g.setColor(Color.BLACK);
            drawReconstructedWave(g);
            
        } else if (drawQuantizedWave) {
            g.drawString("Quantized Samples (" + (1 << levelBits) + " levels)", 10, r.height - 10);
            g.setColor(Color.LIGHT_GRAY);
            if (drawSampledWave)
                drawSampledWave(g);
            if (drawBaseWave)
                drawWave(g);
            g.setColor(Color.BLACK);
            drawQuantizedWave(g);
            
        } else if (drawSampledWave) {
            g.drawString("Samples: " + (int)Math.floor(sampleRate * range), 10, r.height - 10);
            g.setColor(Color.LIGHT_GRAY);
            if (drawBaseWave)
                drawWave(g);
            g.setColor(Color.BLACK);
            drawSampledWave(g);
            
        } else if (drawBaseWave) {
            g.drawString("Time Range: " + getTimeString(), r.width - 200, r.height - 10);
            g.drawString("Composite Wave", 10, r.height - 10);
            g.setColor(Color.BLACK);
            drawWave(g);
        }
    }
    
    private String getBitRate() {
        double rate = sampleRate * levelBits;
        int bitRate = (int)Math.ceil(rate);
        if (bitRate >= 1000000)
            return String.format("%.2fMbps", (rate / 1000000));
        if (bitRate >= 10000) {
            return String.format("%.2fkbps", (rate / 1000));
        } else {
            return bitRate + "bps";
        }
    }

    private String getTimeString() {
        if (range >= 0.1)
            return String.format("%.2fs", range);
        if (range >= 0.0001)
            return String.format("%.2fms", range * 1000);
        if (range >= 0.0000001)
            return String.format("%.2fμs", range * 1000000);
        return null;
    }

    private void drawSimpleWaves(Graphics g2) {
        Graphics2D g = (Graphics2D) g2;
        Rectangle r = g.getClipBounds();
        
        g.setColor(new Color(0xFF888888));
        g.drawString("Simple Waves", 10, r.height - 10);
        
        AffineTransform at = g.getTransform();
        at.translate(0, r.height / 2);
        g.setTransform(at);
        
        double maxAmp = 0;
        for(SimpleWave sw : wave.getSimpleWaves()) {
            if (sw.getAmplitude() > maxAmp) {
                maxAmp = sw.getAmplitude();
            }
        }
        
        for(SimpleWave sw : wave.getSimpleWaves()) {

            if (sw == getSelectedWave()) {
                g.setColor(Color.BLUE);
            } else {
                g.setColor(Color.BLACK);
            }
            
            // (r.width / range) sampling rate results in one sample per pixel
            PolygonDouble waveFormD = sampleWave(new CompositeWave(sw), r.width / range / 2.0, 0, range, false);
            Polygon waveForm = waveFormD.toPolygon(r.width, r.height * V_USED / 2.0 / maxAmp);
            g.drawPolyline(waveForm.xpoints, waveForm.ypoints, waveForm.npoints);
        }
        
        at.translate(0, -r.height / 2);
        g.setTransform(at);
    }

    private void drawWave(Graphics g2) {
        Graphics2D g = (Graphics2D) g2;
        Rectangle r = g.getClipBounds();

        AffineTransform at = g.getTransform();
        
        at.translate(0, r.height / 2);
        g.setTransform(at);
        // (r.width / range) sampling rate results in one sample per pixel
        PolygonDouble waveFormD = sampleWave(wave, r.width / range / 2.0, 0, range);
        Polygon waveForm = waveFormD.toPolygon(r.width, r.height * V_USED / 2.0);
        g.drawPolyline(waveForm.xpoints, waveForm.ypoints, waveForm.npoints);
        at.translate(0, -r.height / 2);
        g.setTransform(at);
    }
    
    private void drawFD(Graphics g2) {
        Graphics2D g = (Graphics2D) g2;
        double fMin = wave.getFundamental();
        double fMax = wave.getFMax();
        double maxHeight = 0;
        for (SimpleWave w : wave.getSimpleWaves()) {
            if (w.getAmplitude() > maxHeight) {
                maxHeight = w.getAmplitude();
            }
        }
        g.setStroke(new BasicStroke(5));
        Rectangle r = g.getClipBounds();

        AffineTransform at = g.getTransform();

        
        g.translate(r.width / 2, 0);
        g.scale(H_USED, 1.0);
        g.translate(-r.width / 2, 0);
        
        //draw Amplitude axis
        g.drawLine(-30,
                r.height / 2,
                -30,
                (int)(r.height / 2.0 * (1.0 - V_USED)));

        g.translate(-80, r.height / 2 - 60);
        g.rotate(Math.PI / 2);
        g.drawString("Amp.", 0, 0);
        g.rotate(-Math.PI / 2);
        g.translate(80, -(r.height / 2 - 60));
        
        
        //draw frequency lines
        int height = 0;
        int xpos;
        double freq = 0;
        for (SimpleWave simple: wave.getSimpleWaves()) {
            height = (int)(simple.getAmplitude() / maxHeight * r.height / 2);
            freq = simple.getFrequency();
            xpos = (int)((freq - fMin) / (fMax - fMin) * r.width);
            
            if (simple == getSelectedWave()) {
                g.setColor(Color.BLUE);
            } else {
                g.setColor(Color.BLACK);
            }
            
            g.drawLine(
                    xpos, 
                    r.height / 2,
                    xpos, 
                    r.height / 2 - (int)(height * V_USED));
            g.translate(xpos, r.height / 2 + 15);
            g.rotate(0.7);
            g.drawString(Integer.toString((int)freq) + "Hz", 0, 0);
            g.rotate(-0.7);
            g.translate(-xpos, -(r.height / 2 + 15));
        }
        g.setTransform(at);
    }
    
    private void drawSampledWave(Graphics g2) {
        Graphics2D g = (Graphics2D) g2;
        Rectangle r = g.getClipBounds();

        PolygonDouble waveFormD = sampleWave(wave, sampleRate, 0, range);
        Polygon waveForm = waveFormD.toPolygon(r.width, r.height * V_USED / 2);
        
        AffineTransform at = g.getTransform();
        at.translate(0, r.height / 2);
        g.setTransform(at);
        g.drawPolyline(waveForm.xpoints, waveForm.ypoints, waveForm.npoints);
        if (waveForm.npoints < 150) { 
        for (int i = 0; i < waveForm.npoints; ++i)
            g.fillOval(waveForm.xpoints[i] - 5, waveForm.ypoints[i] - 5, 10, 10);
        }
        at.translate(0, -r.height / 2);
        g.setTransform(at);
    }
    
    private void drawQuantizedWave(Graphics g2) {
        Graphics2D g = (Graphics2D) g2;
        Rectangle r = g.getClipBounds();

        PolygonDouble waveFormD = sampleWaveQuantized(wave, sampleRate, 0, range, levelBits);
        Polygon waveForm = waveFormD.toPolygon(r.width, r.height * V_USED / 2);
        
        AffineTransform at = g.getTransform();
        at.translate(0, r.height / 2);
        g.setTransform(at);
        g.drawPolyline(waveForm.xpoints, waveForm.ypoints, waveForm.npoints);
        at.translate(0, -r.height / 2);
        g.setTransform(at);
    }

    
    private void drawReconstructedWave(Graphics g2) {
        Graphics2D g = (Graphics2D) g2;
        Rectangle r = g.getClipBounds();

        PolygonDouble waveQD = sampleWaveQuantized(wave, sampleRate, 0, range, levelBits);
        Polygon waveQ = waveQD.toPolygon(r.width, r.height * V_USED / 2);
        
        int[] xpoints = new int[waveQ.npoints / 2];
        int[] ypoints = new int[waveQ.npoints / 2];
        for (int i = 1; i < waveQ.npoints; i+= 2) {
            xpoints[(i - 1) / 2] = waveQ.xpoints[i];
            ypoints[(i - 1) / 2] = waveQ.ypoints[i]; 
        }
        
        AffineTransform at = g.getTransform();
        at.translate(0, r.height / 2);
        g.setTransform(at);
        g.drawPolyline(xpoints, ypoints, waveQ.npoints / 2);
        at.translate(0, -r.height / 2);
        g.setTransform(at);
    }
    
    private void drawBG(Graphics g2) {
        final int divisions = 8;
        Graphics2D g = (Graphics2D) g2;
        Rectangle r = g.getClipBounds();
        
        
        //fill in background
        g.setColor(Color.WHITE);
        g.fillRect(r.x, r.y, r.width, r.height);

        
        //measure lines
        AffineTransform at = g.getTransform();
        g.translate(0, r.height / 2);
        g.scale(1.0, V_USED);
        g.translate(0, -r.height / 2);
        g.setStroke(new BasicStroke(1.0f));
        g.setColor(new Color(0x8FADCC));
        for (int i = 0; i <= divisions; i++)
            g.drawLine(
                    r.x, 
                    r.y + r.height * i / divisions, 
                    r.x + r.width - 1, 
                    r.y + r.height * i / divisions);
        
        g.setTransform(at);

        //base line
        g.setStroke(new BasicStroke(3.0f));
        g.setColor(new Color(0x406080));
        g.drawLine(r.x, r.y + r.height / 2, r.x + r.width - 1, r.y + r.height / 2);
        g.setColor(Color.DARK_GRAY);
        g.drawRect(r.x, r.y, r.width, r.height);
        
    }

    public void setSampleRate(double rate) {
        sampleRate = rate;
        repaint();
    }
    public void setLevelBits(int bits) {
        levelBits = bits;
        repaint();
    }

    public SimpleWave getClickFD(double x) {
        double fMin = wave.getFundamental();
        double fMax = wave.getFMax();
        if (fMax == fMin) {
            fMax = fMin * 2;
        }
        x -= (1.0 - H_USED) / 2;
        x /= H_USED;
        x = x * (fMax - fMin) + fMin;
        
        //check for hits
        SimpleWave closest = null;
        double dist, closestDist = Double.MAX_VALUE;
        for (SimpleWave simple : wave.getSimpleWaves()) {
            dist = Math.abs(simple.getFrequency() - x);
            if ((dist < (fMax - fMin) / 10.0) && (dist < closestDist)) {
                closest = simple;
                closestDist = dist;
            }
        }
        if (closest != null) {
            setSelectedWave(closest);
            return closest;
        }
        
        //otherwise make a new one!
        SimpleWave newWave = new SimpleWave(x);
        wave.add(newWave);
        setSelectedWave(newWave);
        return newWave;
    }

    public SimpleWave getSelectedWave() {
        return selectedWave;
    }

    public void setSelectedWave(SimpleWave selectedWave) {
        this.selectedWave = selectedWave;
    }
}
