/**
 * 
 */
package core;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * 
 * @author Joe Pelz
 * @version 1.0
 */
public class CompositeWave implements Wave{
    private ArrayList<SimpleWave> waves = new ArrayList<SimpleWave>();
    
    public CompositeWave() {}
    public CompositeWave(SimpleWave sw) {
        add(sw);
    }

    public void add(SimpleWave wave) { waves.add(wave); }
    public void remove(SimpleWave wave) {
        for (Iterator<SimpleWave> it = waves.iterator(); it.hasNext();) {
            if (it.next() == wave) {
                it.remove();
                return;
            }
        }
    }
    public void clear() { waves.clear(); }

    public double getFundamental() {
        double min = Double.MAX_VALUE;
        for (SimpleWave wave : waves) {
            if (min > wave.getFrequency()) {
                min = wave.getFrequency();
            }
        }
        return min == Double.MAX_VALUE ? 0 : min;
    }
    public double getFMax() {
        double max = 0;
        for (SimpleWave wave : waves) {
            if (max < wave.getFrequency()) {
                max = wave.getFrequency();
            }
        }
        return max;
    }
    
    public double getAmplitude() {
        double amp = 0;
        for (SimpleWave wave : waves) {
            amp += wave.getAmplitude();
        }
        return amp;
    }
    
    public double sample(double time) {
        double val = 0;
        for (SimpleWave wave : waves) {
            val += wave.sample(time);
        }
        return val;
    }
    
    public double sampleNormalized(double time) {
        double val = sample(time);
        double maxAmp = getAmplitude();
        return val / maxAmp;
    }
    
    public ArrayList<SimpleWave> getSimpleWaves() {
        return waves;
    }
    
    public double getBandwidth() {
        return getFMax() - getFundamental();
    }
}
