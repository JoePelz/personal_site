package core;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

/**
     * <p>Adapted from a tutorial by R.G.Baldwin, 2003.
     * Source:</p>
     * <p>http://www.developer.com/java/other/article.php/2226701/Java-Sound-Creating-Playing-and-Saving-Synthetic-Sounds.htm</p>
     * <p>http://www.dickbaldwin.com</p>
     * @author R.G.Baldwin, Copyright 2003
 * @author Joe Pelz, 2015
 * @version 1.0
 */
public class WavePlayer {

    // Allowable 8000,11025,16000,22050,44100
    private float sampleRate = 16000.0F;
    // Allowable 8,16
    private int sampleSizeInBits = 16;
    // Allowable 1,2
    private int channels = 1;
    // Allowable true,false
    private boolean signed = true;
    // Allowable true,false
    private boolean bigEndian = true;
    
    private Wave src;
    
    private AudioFormat audioFormat;
    private AudioInputStream audioInputStream;
    private SourceDataLine sourceDataLine;
    
    private byte audioData[] = new byte[16000 * 4];
    
//    public static void main(String[] args) {
//        WavePlayer bob = new WavePlayer();
//        CompositeWave wave = new CompositeWave();
//        SimpleWave sw = new SimpleWave(440);
//        wave.add(sw);
//        sw = new SimpleWave(554.37);
//        wave.add(sw);
//        sw = new SimpleWave(659.25);
//        wave.add(sw);
//        bob.setWave(wave);
//        bob.play();
//    }
    
    public void setWave(Wave wave) {
        src = wave;
    }
    
    public void play() {
        //fill buffer
        new SynGen().getSyntheticData(audioData);
        //play file
        playData();
    }
    
    private void playData() {
        try {
            // Get an input stream on the byte array
            // containing the data
            InputStream byteArrayInputStream = new ByteArrayInputStream(audioData);

            // Get the required audio format
            audioFormat = new AudioFormat(
                    sampleRate, 
                    sampleSizeInBits,
                    channels, 
                    signed, 
                    bigEndian);

            // Get an audio input stream from the
            // ByteArrayInputStream
            audioInputStream = new AudioInputStream(
                    byteArrayInputStream,
                    audioFormat, 
                    audioData.length / audioFormat.getFrameSize());

            // Get info on the required data line
            DataLine.Info dataLineInfo = new DataLine.Info(
                    SourceDataLine.class, audioFormat);

            // Get a SourceDataLine object
            sourceDataLine = (SourceDataLine) AudioSystem.getLine(dataLineInfo);

            // Create a thread to play back the data and
            // start it running. It will run until all
            // the data has been played back
            new ListenThread().start();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }
    
    class ListenThread extends Thread {
        // This is a working buffer used to transfer
        // the data between the AudioInputStream and
        // the SourceDataLine. The size is rather
        // arbitrary.
        byte playBuffer[] = new byte[16384];

        public void run() {
            try {

                // Open and start the SourceDataLine
                sourceDataLine.open(audioFormat);
                sourceDataLine.start();

                int cnt;

                // Transfer the audio data to the speakers
                while ((cnt = audioInputStream.read(playBuffer, 0,
                        playBuffer.length)) != -1) {
                    // Keep looping until the input read
                    // method returns -1 for empty stream.
                    if (cnt > 0) {
                        // Write data to the internal buffer of
                        // the data line where it will be
                        // delivered to the speakers in real
                        // time
                        sourceDataLine.write(playBuffer, 0, cnt);
                    }// end if
                }// end while

                // Block and wait for internal buffer of the
                // SourceDataLine to become empty.
                sourceDataLine.drain();

                // Finish with the SourceDataLine
                sourceDataLine.stop();
                sourceDataLine.close();

            } catch (Exception e) {
                e.printStackTrace();
                System.exit(0);
            }// end catch

        }// end run
    }// end inner class ListenThread
     // =============================================//

    // Inner signal generator class.

    // An object of this class can be used to
    // generate a variety of different synthetic
    // audio signals. Each time the getSyntheticData
    // method is called on an object of this class,
    // the method will fill the incoming array with
    // the samples for a synthetic signal.
    class SynGen {
        // Note: Because this class uses a ByteBuffer
        // asShortBuffer to handle the data, it can
        // only be used to generate signed 16-bit
        // data.
        ByteBuffer byteBuffer;
        ShortBuffer shortBuffer;
        int byteLength;
        
        void getSyntheticData(byte[] synDataBuffer) {
            // Prepare the ByteBuffer and the shortBuffer
            // for use
            byteBuffer = ByteBuffer.wrap(synDataBuffer);
            shortBuffer = byteBuffer.asShortBuffer();

            byteLength = synDataBuffer.length;

            // Decide which synthetic data generator
            // method to invoke based on which radio
            // button the user selected in the Center of
            // the GUI. If you add more methods for
            // other synthetic data types, you need to
            // add corresponding radio buttons to the
            // GUI and add statements here to test the
            // new radio buttons. Make additions here
            // if you add new synthetic generator
            // methods.
            tones();
        }// end getSyntheticData method
         // -------------------------------------------//

        // This method generates a monaural tone
        // consisting of the sum of three sinusoids.
        void tones() {
            channels = 1;// Java allows 1 or 2
            // Each channel requires two 8-bit bytes per
            // 16-bit sample.
            int bytesPerSamp = 2;
            sampleRate = 16000.0F;
            // Allowable 8000,11025,16000,22050,44100
            
            int sampLength = byteLength / bytesPerSamp;
            double A = src.getAmplitude();
            for (int cnt = 0; cnt < sampLength; cnt++) {
                double time = cnt / sampleRate;
//                double freq = 950.0; // arbitrary frequency
                double sinValue = src.sample(time) / A;
                shortBuffer.put((short) (16000 * sinValue));
            }
        }
    }
}
