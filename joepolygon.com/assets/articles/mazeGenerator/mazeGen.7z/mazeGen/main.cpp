#include <iostream>
#include "random.h"
#include "maze.h"
//#include <cctype.h>

using namespace std;

int main(int argc, char * argv[]) {
	int sx, sz;
	if (argc == 3) {
		sx = atoi(argv[1]);
		sz = atoi(argv[2]);
	} else {
		sx = 13;
		sz = 8;
	}

    Maze maze;
    maze.setSizeX(sx);
    maze.setSizeZ(sz);
    maze.build();
    cout << maze;
}
