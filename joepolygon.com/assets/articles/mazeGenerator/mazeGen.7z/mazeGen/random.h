#ifndef RANDOM_H
#define RANDOM_H

#include <random>

int get_rand_int(int min, int max);

#endif
