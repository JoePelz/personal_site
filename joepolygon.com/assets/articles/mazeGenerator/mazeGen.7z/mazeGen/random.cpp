#include "random.h"

int get_rand_int(int min, int max) {
  static std::random_device rd{};
  static std::mt19937 engine{ rd() };

  std::uniform_int_distribution<> dist(min, max);
  return dist(engine);
}
