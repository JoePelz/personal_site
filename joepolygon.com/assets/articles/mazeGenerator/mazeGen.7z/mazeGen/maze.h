#ifndef MAZE_H
#define MAZE_H

#include <list>
#include <iomanip>
#include <utility>

#define WALL '+'
#define BARRIER_H '-'
#define BARRIER_V '|'
#define EMPTY ' '
#define UNSET '?'

typedef std::pair<float, float> fPoint;
typedef std::pair<int, int> iPoint;

class Maze {
private:
    char** graph;

    void init();
	void rmGraph();
    std::list<iPoint> getAdjacent(iPoint pos);
    bool canChange(iPoint pos);
    void moveToDest(iPoint& pos);
public:
	int sizeX, sizeZ;

    Maze() : graph(0), sizeX(11), sizeZ(11) { init(); }
	Maze(int sX, int sZ) : graph(0), sizeX((sX << 1) + 1), sizeZ((sZ << 1) + 1) { init(); }

    void setSizeX(int x) { rmGraph(); sizeX = (x << 1) + 1; init(); }
    void setSizeZ(int z) { rmGraph(); sizeZ = (z << 1) + 1; init(); }
    int getSizeX() const { return (sizeX - 1) >> 1; }
    int getSizeY() const { return (sizeZ - 1) >> 1; }
    void display(std::ostream& os) const;
    void build();
	char get(int x, int z) const;
};

std::ostream& operator<<(std::ostream& os, const Maze& maze);
std::ostream& operator<<(std::ostream& os, const fPoint& p);
std::ostream& operator<<(std::ostream& os, const iPoint& p);

#endif
