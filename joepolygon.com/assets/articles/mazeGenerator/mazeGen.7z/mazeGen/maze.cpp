#include <iostream>
#include <list>

#include "Maze.h"
#include "random.h"


void Maze::rmGraph() {
	if (graph != 0) {
        for (int i = 0; i < sizeX; ++i) {
            delete[] graph[i];
        }
        delete[] graph;
    }
}

void Maze::init() {
    graph = new char*[sizeX];
    for (int i = 0; i < sizeX; ++i) {
        graph[i] = new char[sizeZ];
    }

    for (int x = 0; x < sizeX; ++x) {
        for (int z = 0; z < sizeZ; ++z) {
            if ((x & 1) && (z & 1))
                graph[x][z] = UNSET;
            else if (!(x & 1) && !(z & 1))
                graph[x][z] = WALL;
            else
                graph[x][z] = UNSET;
        }
    }
}

std::list<iPoint> Maze::getAdjacent(iPoint pos) {
    std::list<iPoint> results;

    if (pos.first >= 2 && graph[pos.first-1][pos.second] == UNSET)
        results.push_back(iPoint{pos.first - 1, pos.second});
    if (pos.first <= sizeX - 3 && graph[pos.first+1][pos.second] == UNSET)
        results.push_back(iPoint{pos.first + 1, pos.second});

    if (pos.second >= 2 && graph[pos.first][pos.second-1] == UNSET)
        results.push_back(iPoint{pos.first, pos.second - 1});
    if (pos.second <= sizeZ - 3 && graph[pos.first][pos.second+1] == UNSET)
        results.push_back(iPoint{pos.first, pos.second + 1});
    return results;
}

bool Maze::canChange(iPoint pos) {
    return (graph[pos.first-1][pos.second] == UNSET ||
            graph[pos.first+1][pos.second] == UNSET ||
            graph[pos.first][pos.second-1] == UNSET ||
            graph[pos.first][pos.second+1] == UNSET
        );
}

void Maze::moveToDest(iPoint& pos) {
    if (pos.first != 0 && graph[pos.first - 1][pos.second] == UNSET)
        pos.first--;
    else if (pos.first != sizeX - 1 && graph[pos.first + 1][pos.second] == UNSET)
        pos.first++;
    else if (pos.second != 0 && graph[pos.first][pos.second - 1] == UNSET)
        pos.second--;
    else if (pos.second != sizeZ - 1 && graph[pos.first][pos.second + 1] == UNSET)
        pos.second++;
}

void Maze::display(std::ostream& os) const {
    for (int z = sizeZ - 1; z >= 0; --z) {
        for (int x = 0; x < sizeX; ++x) {
            os << graph[x][z];
        }
        os << std::endl;
    }
}

void Maze::build() {
    if (sizeX < 3 || sizeZ < 3)
        return;

    //solidify the border.
    for (int z = 1; z < sizeZ; z += 2) {
        graph[0][z] = BARRIER_V;
        graph[sizeX - 1][z] = BARRIER_V;
    }
    for (int x = 1; x < sizeX; x += 2) {
        graph[x][0] = BARRIER_H;
        graph[x][sizeZ - 1] = BARRIER_H;
    }

    //place the end.
    graph[sizeX - 1][sizeZ - 2] = EMPTY;

    //place the start {0, 1}
    graph[0][1] = UNSET;

    //track open tips in a list.
    std::list<iPoint> options = {{0, 1}};

    //even-even are walls
    //odd-odd are spaces
    //grab random tip. activate it. add new tips to list.
	std::list<iPoint>::size_type newDirs = 2;

    while (!options.empty()) {
        std::list<iPoint>::size_type size = options.size();

		if (size > newDirs && newDirs >= 1) size = newDirs;

        int target = get_rand_int(0, size-1);
        auto it = options.end();
        while (target-- >= 0)
            --it;

        iPoint pos = *it;
        options.erase(it);

        if (graph[pos.first][pos.second] != UNSET)
            continue;

        graph[pos.first][pos.second] = EMPTY;

        moveToDest(pos);

        graph[pos.first][pos.second] = EMPTY;
        auto openings = getAdjacent(pos);
		newDirs = 0;
        for (const auto& newPos : openings) {
            if (canChange(newPos)) {
                options.push_back(newPos);
				newDirs++;
			} else {
                graph[newPos.first][newPos.second] = ((newPos.first & 1) ? BARRIER_H : BARRIER_V);
			}
		}
        options.insert(options.end(), openings.begin(), openings.end());

		//std::cout << *this << std::endl;
    }
}

char Maze::get(int x, int z) const {
	if (x == -1 && z == 1)
		return WALL; //the block behind the entrance
	if (x == sizeX && z == sizeZ - 2)
		return EMPTY; // the block behind the exit
	if (   x >= 0
		&& z >= 0
		&& x < sizeX
		&& z < sizeZ)
		return graph[x][z];
	return WALL;
}

std::ostream& operator<<(std::ostream& os, const Maze& maze) {
    maze.display(os);
    return os;
}
std::ostream& operator<<(std::ostream& os, const fPoint& p) {
    std::ios_base::fmtflags f = os.flags();
    os << std::fixed << std::setprecision(2) << "[" << p.first << ", " << p.second << "]";
    os.flags(f);
    return os;
}
std::ostream& operator<<(std::ostream& os, const iPoint& p) {
    return os << "[" << p.first << ", " << p.second << "]";
}
